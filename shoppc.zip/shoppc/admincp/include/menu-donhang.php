<div style="margin-bottom:10px; margin-top:10px">
<table width="215" border="0" cellspacing="0" cellpadding="0">
  <tr>
   <td class="menu" height="30"><div align="left" style="color:#FFF; font-family:Tahoma; font-size: 13px; font-weight:bold">QUẢN LÝ ĐƠN HÀNG:</div></td>
  </tr>
  <tr>
  	<td background="img/bg_menu42.png" height="30" style="padding-left:5px">
      <strong> KHÁCH</strong></td>
  </tr>
  <tr>
   <td height="70" style="padding-left:5px">
  <div align="left">
   <img align="absmiddle" src="../images/towred1-r.gif"><a href="../admincp/?m=dh&b=gh-guest-list" class="admin-menu-left"> Đơn hàng</a> 
   	<div style="height:10px"></div>
	<img align="absmiddle" src="../images/towred1-r.gif"><a href="../admincp/?m=dh&b=get-guest-list-end" class="admin-menu-left"> Đơn hàng đã giải quyết</a>
	</div>
    </td>
  </tr>
  <tr>
  	<td background="img/bg_menu42.png" height="30" style="padding-left:5px">
      <strong>THÀNH VIÊN</strong></td>
  </tr>
  <tr>
   <td height="70" style="padding-left:5px">
   <div align="left">
   <img align="absmiddle" src="../images/towred1-r.gif"><a href="index.php?m=dh&b=gh-list"> Đơn hàng</a><br>
   <div style="height:10px"></div>
	<img align="absmiddle" src="../images/towred1-r.gif"><a href="../admincp/?m=dh&b=get-list-end" class="admin-menu-left"> Đơn hàng đã giải quyết</a>
   </div>
   </td>
  </tr>
</table>
</div>