
<table width="960" height="35" border="0" cellspacing="0" cellpadding="0" background="../images/demo2.png">
      <tr>       
        <td align="center" width="150" style="color:#FFF"><?php echo "Xin chào: ".$_SESSION['useradmin']; ?> &nbsp; <a href="../admincp/logout.php" style="color:#FFF; font-family:Tahoma; font-size: 12px; font-weight:bold;">Thoát</a></td>
        <td align="left" width="460" style="color:#FFF"> | <a href="../admincp/?m=changepw" style="color:#FFF; font-family:Tahoma; font-size: 12px; font-weight:bold;">Đổi mật khẩu</a></td>

  </tr>
</table>   
<marquee behavior="alternate"> <font color="#d4340c"> <?php echo "Chào mừng ".$_SESSION['useradmin']." đến với trang quản trị"; ?></font></marquee> 