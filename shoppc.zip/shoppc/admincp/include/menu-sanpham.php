<table width="215" border="0" cellspacing="0" cellpadding="0">
  <tr>
   <td class="menu" height="30"><div align="left" style="color:#FFF; font-family:Tahoma; font-size: 13px; font-weight:bold">QUẢN LÝ SẢN PHẨM:</div></td>
  </tr>
  <tr>
   <td height="50" style="padding-left:20px">
   <div align="left">
   <img align="absmiddle" src="../images/towred1-r.gif"><a href="../admincp/?m=sp&b=sp-insert" class="admin-menu-left"> Thêm sản phẩm mới.</a><br>
	<div style="height:10px"></div>
	<img align="absmiddle" src="../images/towred1-r.gif"><a href="../admincp/?m=sp&b=sp-list" class="admin-menu-left"> Danh sách sản phẩm</a>    
    </div>
   </td>   
  </tr>
  <tr>
  	<td><?php include "include/menu-tree.php"; ?></td>
  </tr>
</table>

