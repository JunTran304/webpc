<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Auto Suggest</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<script type="text/javascript" src="ajax.js"></script>
<script type="text/javascript">
</script>
<link href="styles.css" rel="stylesheet" type="text/css"></link>	
<!--[if IE]>
  <link rel="stylesheet" type="text/css" href="i_hate_IE.css" />
<![endif]-->
</head>
<body>
<center>
	Enter the text you are Searching:
	  <input type="text" onKeyUp="getScriptPage('box','text_content')" id="text_content" size="40">	
	<div id="box"></div>

</center>
</body>
</html>
