<?php
	$HOST = "localhost";
	$USER = "u602164897_root";
	$PASS = "";
	$DB = "u602164897_shop";
	$ERROR1 = "Loi ";
	$ERROR2 = "Loi DB";
@mysql_connect($HOST, $USER, $PASS) or die($ERROR1);
@mysql_select_db($DB) or die($ERROR2);
mysql_query("SET NAMES 'utf8'");
?>