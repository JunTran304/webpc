<style type="text/css">
<!--
.style1 {
	color: #0000FF;
	font-weight: bold;
}
.style2 {
	color: #FF0000;
	font-weight: bold;
}
.style8 {
	font-size: 18px;
	color: #FF00FF;
	font-weight: bold;
}
-->
</style>
<div align="justify" style="width:550;line-height:20px">
<div align="center">
   <div class="style8" align="center"><br />
  WEBSITE KINH DOANH MÁY TÍNH TRỰC TUYẾN</div>
   <p><br>
  <span class="style2">Chuyên kinh doanh các dòng laptop từ các thương hiệu nổi tiếng với mức giá rẻ nhất thị trường và chất lượng hàng đầu.</span></p>
   <p><br>
   </p>
  <div align="right"><span class="style1"><br>
    <br>  
    <br>
</span></div>

  <table width="550" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="200"  rowspan="3" align="right" style="border-right:1px dotted #CCCCCC"><div style="font-size:18px;"><strong>Số điện thoại:</strong></div></td>
      <td style="color:#0000FF; font-size:18px; padding-left:30px"><strong><span style="font-size: 18px; color: #FF0000">0903156306</span></strong></td>      
    </tr>
    <tr>
      <td style="color:#0000FF; font-size:18px; padding-left:30px"><span style="color:#FF0000; font-size:18px"><strong>01654886996</strong></span></td>
    </tr>
     <tr>
      <td style="color:#0000FF; font-size:18px; padding-left:30px">&nbsp;</td>
    </tr>
   <tr><td colspan="2"><hr /></td></tr>
    <tr>
      <td width="200"  rowspan="3" align="right" style="border-right:1px dotted #CCCCCC"><div style="font-size:18px;"><strong>Hỗ trợ online:</strong></div></td>
      <td style="color:#0000FF; font-size:18px; padding-left:30px"><span class="title">TranMinh@gmail.com</span></font></font></td>      
    </tr>
    <tr>
      <td style="color:#0000FF; font-size:18px; padding-left:30px">Tranquangminh.304@gmail.com</span></font></font></td>
    </tr>
     <tr>
      <td style="color:#0000FF; font-size:18px; padding-left:30px">&nbsp;</td>
    </tr>
    </table>
 

</div>
