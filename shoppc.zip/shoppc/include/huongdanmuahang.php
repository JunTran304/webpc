<div>
<div style="text-align: center;">
<span style="color: #d4340c; font-size: large;">
<strong>HƯỚNG DẪN MUA HÀNG</strong></span></div>
</div>
<div>
<span style="color: #d4340c;"><strong><br />
</strong></span><center><img src="images/Giao-hang.png"></div>
<span style="color: red;"><strong>Đối với thành viên của website:</strong></span><br />
<strong>» Bước 1:</strong> Đăng nhập vào website.<br />
<strong>» Bước 2:</strong> Lựa chọn sản phẩm trên web và cho vào giỏ hàng.<br />
<strong>» Bước 3:</strong> Nhấn vào nút "Đặt hàng" để gửi đơn đặt hàng cho công ty.<br />
<br />
<span style="color: red;"><strong>Đối với khách (chưa đăng ký thành viên) của website:</strong></span><br />
<strong>» Bước 1:</strong> Lựa chọn sản phẩm trên web và cho vào giỏ hàng.<br />
<strong>» Bước 2:</strong> Nhấn vào nút "Đặt hàng".<br />
<strong>» Bước 3:</strong> Quý khách nhập những thông tin cần thiết để chúng tôi có thể liên hệ.<br />
<span style="color: red;"><strong><br />Nhân viên tổng đài sẽ liên lạc với bạn trong vòng 24h để xác nhận đơn hàng và địa chỉ nhận hàng.&nbsp;</strong></span><br />
<span style="color: red;"><strong>Hàng sẽ được chuyển đến tận nơi khách hàng yêu cầu từ 1 đến 7 ngày và hoàn toàn miễn phí cước vận chuyển. Quý khách thanh toán trực tiếp với nhận viên giao hàng.</strong></span><br />
<br />
<br />
<br />
<div align="center">
<div align="center" style="height: 100px; line-height: 25px; width: 500px;">
<strong><span style="color: #d4340c;">XIN CHÂN THÀNH CẢM ƠN QUÝ KHÁCH!</span></strong></div>
</div>
