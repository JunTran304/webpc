<table width="195" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="195" height="35" background="images/bgn_hotro2.png"><div align="left" style="color:#FFF; font-family:Tahoma; font-size: 14px; padding-left:30px">HỖ TRỢ</div></td>
  </tr>
  <tr>
        <td background="images/toplist-content.gif" style="border-left: 1px solid #CCCCCC;border-right: 1px solid #CCCCCC; background-repeat:repeat-x"> 
    <div style="line-height:20px">
    <div style="padding-left:20px; padding-top:3px;"><strong>&raquo;Tranminh@gmail.com</strong></div>
	
    </div>
    </td>
    <tr>
    	<td height="30px" style="border-bottom: 1px solid #CCCCCC;border-left: 1px solid #CCCCCC;border-right: 1px solid #CCCCCC;">
        	
      </td>
    </tr>
  </tr>
</table>